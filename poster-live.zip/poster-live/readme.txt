=== Poster Live ===
Contributors: Mohsen Soleymani
Tags: posts,live posts,ajax live,display posts by category,post categories,poster live,posts by category,show posts by category
Requires at least: 5.7
Tested up to: 5.8.1
Requires PHP: 5.2
Stable tag: 1.0.0
License: GPL V2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A plugin that shows posts in a separate, live and very beautiful category.

== Description ==
A plugin that shows posts in a separate, live and very beautiful category.

== Installation ==

   1.  Upload the Poster Live plugin file (poster-live.zip) to the /wp-content/plugins/ directory.
   2.  Activate the plugin through the ‘Plugins’ menu in WordPress.
   3. use shortcode [poster_live] where ever  you want.
