jQuery(document).ready(function($){
    $('.poster_live_tab_item:nth-child(1)').addClass('poster_live_active');
    jQuery('.poster_live_tab_item').click(function(event){
        jQuery('.poster_live_posts_cat').css('display','none');
       var cat_id=$(this).attr('data-catID');
       $('.poster_live_posts_cat_'+cat_id).css('display','block');
       $('.poster_live_tab_item').removeClass('poster_live_active');
       $('.poster_live_tab_item[data-catID='+cat_id+']').addClass('poster_live_active')
        
    });
    var posts_parent_width=$('.poster_live_posts').parent().width();
    if(posts_parent_width<=480){
        $('.poster_live_posts').css('grid-template-columns','100%')
    }else if(posts_parent_width>480 && posts_parent_width<768){
        $('.poster_live_posts').css('grid-template-columns','50% 50%')
    }else if(posts_parent_width>=768 && posts_parent_width<1024){
        $('.poster_live_posts').css('grid-template-columns','33.3% 33.3% 33.3%')
    }else{
        $('.poster_live_posts').css('grid-template-columns','25% 25% 25% 25%');
    }
    $(window).resize(function(){
        var posts_parent_width=$('.poster_live_posts').parent().width();
        if(posts_parent_width<=480){
            $('.poster_live_posts').css('grid-template-columns','100%');
        }else if(posts_parent_width>480 && posts_parent_width<768){
            $('.poster_live_posts').css('grid-template-columns','50% 50%');
        }else if(posts_parent_width>=768 && posts_parent_width<1024){
            $('.poster_live_posts').css('grid-template-columns','33.3% 33.3% 33.3%');
        }else{
            $('.poster_live_posts').css('grid-template-columns','25% 25% 25% 25%');
        }
    });
    
});