
<li class="poster_live_tab_item" data-catID="<?php echo esc_attr($cat->term_id) ;?>">
<?php echo esc_attr($cat->name) ; ?>
</li>
